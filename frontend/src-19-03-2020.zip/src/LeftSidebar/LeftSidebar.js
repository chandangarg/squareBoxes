import React from 'react';
import './LeftSidebar.css';

class LeftSidebar extends React.Component {
  render() {
    return (
            <div>
                <h2>Catch Advisory Group</h2>
                <div className="note-box-main">
                    <div className="note-box">
                        <h3><i className="fa fa-life-ring" aria-hidden="true"></i>Tips for risk</h3>
                        <div className="note-text mb-3">Every question you ask should help you gather either facts or an opinion. Know which kind of
                            information.
                        </div>
                        <h3><i className="fa fa-life-ring" aria-hidden="true"></i>Tips for risk</h3>
                        <div className="note-text pb-0 border-0">Even if you don’t find a useful answer elsewhere on the site, including links to releted questions
                            that haven’t helped can help others in understanding.</div>
                    </div>
                    <div className="note-link">
                        <a href="{e => e.preventDefault()}">Still need help? Contact Support</a>
                    </div>
                </div>
            </div>    
    )    
  }
}

export default LeftSidebar;
